/**
 * Write a description of class Operador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Operador
{
    public static void main(String args[]){
        int a=8;
        int b=3;
        int suma= a+b;
        int resta= a-b;
        int mul=a*b;
        int div=a/b;
        System.out.println("suma:"+suma);
        System.out.println("resta:"+resta);
        System.out.println("multiplicacion:"+mul);
        System.out.println("division:"+div);
    }
}